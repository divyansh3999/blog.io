import './newDnd/style.css';
import MaterialUi from './MaterialUi';
import ReactDnd from './react-dnd/ReactDnd';
import New from './react-dnd/New';
import React from "react"
import IndexDnd from './newDnd/IndexDnd';

function App() {
  return (
    // <MaterialUi/>
   <>
      {/* <ReactDnd/>
      <New/> */}
      <IndexDnd/>
   </>
  );
}

export default App;
