import React from 'react'

export default function Video() {
  return (
    <>
        <div className="container videoBox">
            <div className="row">
                <div className="col-md-8 col-sm-12 offset-md-2">
                    <div className="text-center videoImg">
                    <img src="https://www.comet.ml/site/app/uploads/2020/02/video_image-1-e1587413725588.png" alt="" />
                    </div>
                </div>
            </div>
        </div>
    </>
  )
}
